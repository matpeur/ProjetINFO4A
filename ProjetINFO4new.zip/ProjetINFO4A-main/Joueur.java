import java.io.*;

public class Joueur extends Creature
{
  char[] commandes;
  boolean arret;
  int score;
 public Joueur(Plateau I1,String nom, int id, char symbole,int score1)
 {
   super(nom, id, I1);
   commandes = new char[]{'z', 'q', 's', 'd'};
   arret=false;
   score=score1;
   super.setSymbole(symbole);
 }

  public String toString()
  {
    return "Joueur: "+super.getNom();
  }
  public void setScore(int n){this.score=n;}
  public void ajoutScore(int n){setSCore(this.score+n);}
  public int getScore(){return this.score;}
  @Override
  public void run()
  {
    while(!arret)
    {
      try
      {
        BufferedReader saisie=new BufferedReader(new InputStreamReader(System.in));
        char commande =(char)saisie.read();
        if(commande==commandes[0])
          {
            deplaceHaut();
          }
          else if(commande==commandes[1])
          {
            deplaceDroite();
          }
          else if(commande==commandes[2])
          {
            deplaceBas();
          }
          else if(commande==commandes[3])
          {
            deplaceDroite();
          }
        }
        catch(IOException e){}
    }
  }

}
